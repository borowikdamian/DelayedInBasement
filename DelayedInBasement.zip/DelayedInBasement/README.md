# DelayedInBasement
to strona internetowa umozliwiajaca wyszukiwanie autorow i postow, komentarzy do postow.
technologie ktore wykorzystujemy przy projekcie to: html, css, python oraz jego framework flask

jak to uruchomic?
1. zainstaluj flask
-> pip install flask
2. ustaw aplikacje
-> export FLASK_APP=app.py 
3. wlacz serwer flask
-> flask run
4. w przegladarce polacz sie ze strona
-> http://127.0.0.1:5000
